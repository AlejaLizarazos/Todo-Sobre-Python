def elevar(a,b):
    print(a**b)

def redondear(a):
    print(round(a))

    