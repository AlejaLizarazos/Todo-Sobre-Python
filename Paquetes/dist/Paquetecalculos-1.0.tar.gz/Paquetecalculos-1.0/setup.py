from setuptools import setup

setup(

    name = "Paquetecalculos",
    version = "1.0",
    description = "Paquete de redondeo y potencia",
    author = "Aleja",
    author_email = "alejalizarazo98@gmail.com",
    packages = ["Calculos","Calculos.redondeo_potencia"]

)

